package com.naoteilit.zmanim.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.IOException

/**
 * Thin client around the undocumented but functional endpoint the
 * matara.pro/nedarimplus/Zmanim/result.html page itself calls via AJAX:
 *
 *   GET https://www.matara.pro/nedarimplus/Zmanim/Manage.aspx
 *       ?Action=GetNearestMinyan&lat={lat}&lng={lng}&radius={radiusKm}
 *
 * IMPORTANT: this endpoint is not officially published for third-party use.
 * See the investigation report for details/caveats. Treat schema changes as
 * possible; all parsing below is defensive (optString, empty list fallback).
 */
class NedarimPlusApi(
    private val client: OkHttpClient = OkHttpClient()
) {
    companion object {
        private const val BASE_URL =
            "https://www.matara.pro/nedarimplus/Zmanim/Manage.aspx"
    }

    /**
     * Fetches all minyanim within [radiusKm] of ([lat], [lng]).
     * Throws IOException on network failure or unexpected HTTP status.
     */
    suspend fun getNearbyMinyanim(
        lat: Double,
        lng: Double,
        radiusKm: Double
    ): List<Minyan> = withContext(Dispatchers.IO) {
        val url = "$BASE_URL?Action=GetNearestMinyan" +
            "&lat=$lat&lng=$lng&radius=$radiusKm" +
            "&_=${System.currentTimeMillis()}"

        val request = Request.Builder().url(url).build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IOException("שגיאת שרת: HTTP ${response.code}")
            }
            val body = response.body?.string().orEmpty()
            parseMinyanim(body)
        }
    }

    private fun parseMinyanim(rawJson: String): List<Minyan> {
        if (rawJson.isBlank()) return emptyList()
        return try {
            val root = JSONObject(rawJson)
            val arr = root.optJSONArray("data") ?: return emptyList()
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Minyan(
                    tefila = o.optString("T"),
                    institutionName = o.optString("L"),
                    hour = o.optString("H"),
                    comment = o.optString("C"),
                    distanceText = o.optString("D"),
                    institutionId = o.optString("M"),
                    address = o.optString("A"),
                    coords = o.optString("W")
                )
            }
        } catch (e: Exception) {
            // Schema changed or malformed response - fail soft, not with a crash.
            emptyList()
        }
    }
}
