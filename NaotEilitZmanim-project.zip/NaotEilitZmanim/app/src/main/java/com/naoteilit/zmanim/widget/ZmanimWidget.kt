package com.naoteilit.zmanim.widget

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.action.actionStartActivity
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.action.clickable
import androidx.glance.layout.Alignment
import androidx.glance.layout.Column
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.padding
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextAlign
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.naoteilit.zmanim.MainActivity
import com.naoteilit.zmanim.data.Config
import com.naoteilit.zmanim.data.Minyan
import com.naoteilit.zmanim.data.ZmanimRepository
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.sp

class ZmanimWidget : GlanceAppWidget() {

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val repository = ZmanimRepository()

        val ourShul: List<Minyan> = try {
            repository.fetch().ourShul
        } catch (e: Exception) {
            emptyList()
        }

        provideContent {
            WidgetContent(ourShul)
        }
    }

    @Composable
    private fun WidgetContent(times: List<Minyan>) {
        Column(
            modifier = GlanceModifier
                .fillMaxSize()
                .background(Color(0xFF1E4B8A))
                .padding(12.dp)
                .clickable(actionStartActivity<MainActivity>()),
            horizontalAlignment = Alignment.Horizontal.CenterHorizontally
        ) {
            Text(
                text = Config.NAOT_EILIT_DISPLAY_NAME,
                style = TextStyle(
                    color = ColorProvider(Color.White),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center
                )
            )

            if (times.isEmpty()) {
                Text(
                    text = "אין נתונים כרגע",
                    style = TextStyle(
                        color = ColorProvider(Color.White),
                        fontSize = 12.sp
                    )
                )
            } else {
                // Show up to 3 upcoming entries to keep the widget compact.
                times.take(3).forEach { minyan ->
                    Text(
                        text = "${minyan.tefila}  ${minyan.hour}",
                        style = TextStyle(
                            color = ColorProvider(Color(0xFFF2C744)),
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            textAlign = TextAlign.Center
                        )
                    )
                }
            }
        }
    }
}
